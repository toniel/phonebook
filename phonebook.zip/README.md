# phonebook
phonebook with laravel 5.8 + vue + bulma

#Source Tutorial [Youtube](https://www.youtube.com/watch?v=J_ayfPetE2M&list=PLe30vg_FG4OSl8zlikYc_RLkfueqAMUb_)

#Installasi
1. clone repo
2. go to phonebook folder
3. run composer install
4. run npm install
5. copy .env.example to .env
6. setting database configuration 
7. run php artisan:migrate
8. run php artisan serve

