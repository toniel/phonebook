<template>
    <footer class="footer">
    <div class="content has-text-centered">
        <p>
        <strong>Vue JS Phonebook APP</strong> by <a href="https://toni-listiyo.com">Toni Listiyo</a>
        </p>
    </div>
    </footer>
</template>
